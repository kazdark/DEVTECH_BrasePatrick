<?php

function logActivity($conn, $action)
{
    if (!isset($_SESSION["user_id"])) {
        return;
    }

    $user_id = $_SESSION["user_id"];

    $stmt = $conn->prepare("
        INSERT INTO activity_logs
        (user_id, action)
        VALUES (?, ?)
    ");

    $stmt->bind_param(
        "is",
        $user_id,
        $action
    );

    $stmt->execute();

    $stmt->close();
}

?>