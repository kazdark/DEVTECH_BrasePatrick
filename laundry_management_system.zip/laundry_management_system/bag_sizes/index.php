<?php

require_once "../includes/auth.php";
require_once "../config/database.php";

$result = $conn->query("
    SELECT *
    FROM bag_sizes
    ORDER BY id ASC
");

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Bag Size Management</title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background: #f1f5f9;
            margin: 0;
        }

        .container {
            width: 90%;
            margin: 30px auto;
        }

        .top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .top a {
            background: #2563eb;
            color: white;
            padding: 10px 15px;
            text-decoration: none;
            border-radius: 6px;
        }

        .table-box {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.08);
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }

        th {
            background: #2563eb;
            color: white;
        }

        .back {
            display: inline-block;
            margin-bottom: 15px;
            color: #2563eb;
            text-decoration: none;
        }

        .action-btn {
            background: #2563eb;
            color: white;
            padding: 7px 12px;
            text-decoration: none;
            border-radius: 5px;
            margin-right: 5px;
            display: inline-block;
        }

        .delete-btn {
            background: #dc2626;
        }

        .action-btn:hover {
            opacity: 0.9;
        }

    </style>

</head>

<body>

<div class="container">

    <a class="back" href="../dashboard.php">
        ← Back to Dashboard
    </a>

    <div class="top">

        <h1>Bag Size Management</h1>

        <a href="add.php">
            + Add Bag Size
        </a>

    </div>

    <div class="table-box">

        <table>

            <thead>

                <tr>

                    <th>ID</th>
                    <th>Bag Name</th>
                    <th>Description</th>
                    <th>Status</th>
                    <th>Action</th>

                </tr>

            </thead>

            <tbody>

                <?php if ($result && $result->num_rows > 0): ?>

                    <?php while ($bag = $result->fetch_assoc()): ?>

                        <tr>

                            <td>
                                <?php echo $bag['id']; ?>
                            </td>

                            <td>
                                <?php echo htmlspecialchars($bag['bag_name']); ?>
                            </td>

                            <td>

                                <?php

                                if (!empty($bag['description'])) {

                                    echo htmlspecialchars($bag['description']);

                                } else {

                                    echo "No description";

                                }

                                ?>

                            </td>

                            <td>
                                <?php echo htmlspecialchars($bag['status']); ?>
                            </td>

                            <td>

                                <a
                                    class="action-btn"
                                    href="edit.php?id=<?php echo $bag['id']; ?>"
                                >
                                    Edit
                                </a>

                                <a
                                    class="action-btn delete-btn"
                                    href="delete.php?id=<?php echo $bag['id']; ?>"
                                    onclick="return confirm('Are you sure you want to delete this bag size?');"
                                >
                                    Delete
                                </a>

                            </td>

                        </tr>

                    <?php endwhile; ?>

                <?php else: ?>

                    <tr>

                        <td colspan="5" style="text-align: center;">
                            No bag sizes registered yet.
                        </td>

                    </tr>

                <?php endif; ?>

            </tbody>

        </table>

    </div>

</div>

</body>

</html>