<?php

require_once "../includes/auth.php";
require_once "../config/database.php";

$message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $bag_name = trim($_POST["bag_name"]);
    $description = trim($_POST["description"]);
    $status = $_POST["status"];

    if ($bag_name === "" || $description === "") {

        $message = "Please complete all fields.";

    } else {

        $stmt = $conn->prepare("
            INSERT INTO bag_sizes
            (bag_name, description, status)
            VALUES (?, ?, ?)
        ");

        $stmt->bind_param(
            "sss",
            $bag_name,
            $description,
            $status
        );

        if ($stmt->execute()) {

            header("Location: index.php");
            exit();

        } else {

            $message = "Failed to add bag size.";

        }

        $stmt->close();
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Add Bag Size</title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background: #f1f5f9;
            margin: 0;
        }

        .container {
            width: 90%;
            max-width: 600px;
            margin: 40px auto;
        }

        .back {
            display: inline-block;
            margin-bottom: 20px;
            color: #2563eb;
            text-decoration: none;
        }

        .box {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.08);
        }

        h1 {
            margin-top: 0;
        }

        .group {
            margin-bottom: 18px;
        }

        label {
            display: block;
            margin-bottom: 7px;
            font-weight: bold;
        }

        input,
        textarea,
        select {
            width: 100%;
            padding: 10px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 15px;
        }

        textarea {
            min-height: 100px;
            resize: vertical;
        }

        button {
            width: 100%;
            padding: 12px;
            border: none;
            border-radius: 6px;
            background: #2563eb;
            color: white;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background: #1d4ed8;
        }

        .message {
            background: #fee2e2;
            color: #991b1b;
            padding: 10px;
            border-radius: 6px;
            margin-bottom: 15px;
        }

    </style>

</head>

<body>

<div class="container">

    <a class="back" href="index.php">
        ← Back to Bag Sizes
    </a>

    <div class="box">

        <h1>Add Bag Size</h1>

        <?php if ($message !== ""): ?>

            <div class="message">
                <?php echo htmlspecialchars($message); ?>
            </div>

        <?php endif; ?>

        <form method="POST">

            <div class="group">

                <label>
                    Bag Name
                </label>

                <input
                    type="text"
                    name="bag_name"
                    placeholder="Example: Small"
                    required
                >

            </div>

            <div class="group">

                <label>
                    Description
                </label>

                <textarea
                    name="description"
                    placeholder="Enter the description of this bag size."
                    required
                ></textarea>

            </div>

            <div class="group">

                <label>
                    Status
                </label>

                <select name="status" required>

                    <option value="Active">
                        Active
                    </option>

                    <option value="Inactive">
                        Inactive
                    </option>

                </select>

            </div>

            <button type="submit">
                Add Bag Size
            </button>

        </form>

    </div>

</div>

</body>

</html>