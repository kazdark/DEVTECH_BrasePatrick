<?php

require_once "../includes/auth.php";
require_once "../config/database.php";
require_once "../includes/activity_log.php";

if (!isset($_GET["id"]) || !is_numeric($_GET["id"])) {
    header("Location: index.php");
    exit();
}

$id = (int) $_GET["id"];

$stmt = $conn->prepare("SELECT * FROM customers WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows !== 1) {
    header("Location: index.php");
    exit();
}

$customer = $result->fetch_assoc();

$stmt->close();

$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $fullname = trim($_POST["fullname"]);
    $contact = trim($_POST["contact"]);
    $address = trim($_POST["address"]);

    if (empty($fullname)) {

        $error = "Full name is required.";

    } else {

        $stmt = $conn->prepare(
            "UPDATE customers
             SET fullname = ?, contact = ?, address = ?
             WHERE id = ?"
        );

        $stmt->bind_param(
            "sssi",
            $fullname,
            $contact,
            $address,
            $id
        );

        if ($stmt->execute()) {

            /*
            |--------------------------------------------------------------------------
            | Activity Log
            |--------------------------------------------------------------------------
            */

            logActivity(
                $conn,
                "Updated customer: " . $fullname
            );

            header("Location: index.php");
            exit();

        } else {

            $error = "Failed to update customer.";

        }

        $stmt->close();
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Edit Customer</title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background: #f1f5f9;
            margin: 0;
        }

        .container {
            width: 500px;
            margin: 50px auto;
        }

        .form-box {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.08);
        }

        h1 {
            margin-top: 0;
        }

        label {
            display: block;
            margin-top: 15px;
            margin-bottom: 6px;
            font-weight: bold;
        }

        input,
        textarea {
            width: 100%;
            padding: 11px;
            border: 1px solid #ccc;
            border-radius: 6px;
            box-sizing: border-box;
        }

        textarea {
            height: 90px;
            resize: vertical;
        }

        button {
            width: 100%;
            margin-top: 20px;
            padding: 12px;
            border: none;
            border-radius: 6px;
            background: #2563eb;
            color: white;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background: #1d4ed8;
        }

        .back {
            display: inline-block;
            margin-bottom: 15px;
            color: #2563eb;
            text-decoration: none;
        }

        .error {
            background: #fee2e2;
            color: #b91c1c;
            padding: 10px;
            border-radius: 6px;
            margin-bottom: 15px;
        }

    </style>

</head>

<body>

<div class="container">

    <a class="back" href="index.php">
        ← Back to Customers
    </a>

    <div class="form-box">

        <h1>Edit Customer</h1>

        <?php if (!empty($error)): ?>

            <div class="error">
                <?php echo htmlspecialchars($error); ?>
            </div>

        <?php endif; ?>

        <form method="POST">

            <label>Full Name</label>

            <input
                type="text"
                name="fullname"
                value="<?php echo htmlspecialchars($customer['fullname']); ?>"
                required
            >

            <label>Contact Number</label>

            <input
                type="text"
                name="contact"
                value="<?php echo htmlspecialchars($customer['contact']); ?>"
            >

            <label>Address</label>

            <textarea
                name="address"
            ><?php echo htmlspecialchars($customer['address']); ?></textarea>

            <button type="submit">
                Update Customer
            </button>

        </form>

    </div>

</div>

</body>

</html>