<?php

require_once "../includes/auth.php";
require_once "../config/database.php";

$result = $conn->query("SELECT * FROM customers ORDER BY id DESC");

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Customer Management</title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background: #f1f5f9;
            margin: 0;
        }

        .container {
            width: 90%;
            margin: 30px auto;
        }

        .top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .top a {
            background: #2563eb;
            color: white;
            padding: 10px 15px;
            text-decoration: none;
            border-radius: 6px;
        }

        .table-box {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.08);
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }

        th {
            background: #2563eb;
            color: white;
        }

        .back {
            display: inline-block;
            margin-bottom: 15px;
            color: #2563eb;
            text-decoration: none;
        }

        .action-btn {
            background: #2563eb;
            color: white;
            padding: 7px 12px;
            text-decoration: none;
            border-radius: 5px;
            margin-right: 5px;
            display: inline-block;
        }

        .action-btn:hover {
            background: #1d4ed8;
        }

        .delete-btn {
            background: #dc2626;
        }

        .delete-btn:hover {
            background: #b91c1c;
        }

    </style>

</head>

<body>

<div class="container">

    <a class="back" href="../dashboard.php">
        ← Back to Dashboard
    </a>

    <div class="top">

        <h1>Customer Management</h1>

        <a href="add.php">
            + Add Customer
        </a>

    </div>

    <div class="table-box">

        <table>

            <thead>

                <tr>

                    <th>ID</th>

                    <th>Full Name</th>

                    <th>Contact</th>

                    <th>Address</th>

                    <th>Date Registered</th>

                    <th>Action</th>

                </tr>

            </thead>

            <tbody>

                <?php if ($result->num_rows > 0): ?>

                    <?php while ($customer = $result->fetch_assoc()): ?>

                        <tr>

                            <td>
                                <?php echo $customer['id']; ?>
                            </td>

                            <td>
                                <?php echo htmlspecialchars($customer['fullname']); ?>
                            </td>

                            <td>
                                <?php echo htmlspecialchars($customer['contact']); ?>
                            </td>

                            <td>
                                <?php echo htmlspecialchars($customer['address']); ?>
                            </td>

                            <td>
                                <?php echo $customer['created_at']; ?>
                            </td>

                            <td>

                                <a
                                    class="action-btn"
                                    href="edit.php?id=<?php echo $customer['id']; ?>"
                                >
                                    Edit
                                </a>

                                <a
                                    class="action-btn delete-btn"
                                    href="delete.php?id=<?php echo $customer['id']; ?>"
                                    onclick="return confirm('Are you sure you want to delete this customer?');"
                                >
                                    Delete
                                </a>

                            </td>

                        </tr>

                    <?php endwhile; ?>

                <?php else: ?>

                    <tr>

                        <td colspan="6" style="text-align: center;">
                            No customers registered yet.
                        </td>

                    </tr>

                <?php endif; ?>

            </tbody>

        </table>

    </div>

</div>

</body>

</html>