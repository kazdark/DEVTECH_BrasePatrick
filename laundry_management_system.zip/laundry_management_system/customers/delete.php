<?php

require_once "../includes/auth.php";
require_once "../config/database.php";
require_once "../includes/activity_log.php";

if (!isset($_GET["id"]) || !is_numeric($_GET["id"])) {
    header("Location: index.php");
    exit();
}

$id = (int) $_GET["id"];

/*
|--------------------------------------------------------------------------
| Get Customer
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare("
    SELECT fullname
    FROM customers
    WHERE id = ?
    LIMIT 1
");

$stmt->bind_param("i", $id);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header("Location: index.php");
    exit();
}

$customer = $result->fetch_assoc();

$stmt->close();

$fullname = $customer["fullname"];


/*
|--------------------------------------------------------------------------
| Check Existing Orders
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare("
    SELECT COUNT(*) AS total_orders
    FROM laundry_orders
    WHERE customer_id = ?
");

$stmt->bind_param("i", $id);
$stmt->execute();

$result = $stmt->get_result();
$order_data = $result->fetch_assoc();

$stmt->close();


/*
|--------------------------------------------------------------------------
| Prevent Delete if Customer Has Orders
|--------------------------------------------------------------------------
*/

if ($order_data["total_orders"] > 0) {

    echo "
    <!DOCTYPE html>
    <html lang='en'>
    <head>
        <meta charset='UTF-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <title>Cannot Delete Customer</title>

        <style>

            body {
                font-family: Arial, sans-serif;
                background: #f1f5f9;
                margin: 0;
            }

            .container {
                width: 90%;
                max-width: 500px;
                margin: 100px auto;
            }

            .box {
                background: white;
                padding: 30px;
                border-radius: 10px;
                box-shadow: 0 3px 10px rgba(0,0,0,0.08);
                text-align: center;
            }

            h2 {
                color: #b91c1c;
            }

            p {
                color: #475569;
                line-height: 1.5;
            }

            .back {
                display: inline-block;
                margin-top: 15px;
                padding: 10px 18px;
                background: #2563eb;
                color: white;
                text-decoration: none;
                border-radius: 6px;
            }

        </style>

    </head>

    <body>

        <div class='container'>

            <div class='box'>

                <h2>Cannot Delete Customer</h2>

                <p>
                    Customer <strong>" . htmlspecialchars($fullname) . "</strong>
                    cannot be deleted because this customer has existing
                    laundry orders.
                </p>

                <p>
                    Existing orders must be preserved to maintain
                    accurate transaction records.
                </p>

                <a class='back' href='index.php'>
                    ← Back to Customers
                </a>

            </div>

        </div>

    </body>
    </html>
    ";

    exit();
}


/*
|--------------------------------------------------------------------------
| Delete Customer
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare("
    DELETE FROM customers
    WHERE id = ?
");

$stmt->bind_param("i", $id);

if ($stmt->execute()) {

    /*
    |--------------------------------------------------------------------------
    | Activity Log
    |--------------------------------------------------------------------------
    */

    logActivity(
        $conn,
        "Deleted customer: " . $fullname
    );

    header("Location: index.php");
    exit();

} else {

    echo "Failed to delete customer.";

}

$stmt->close();

?>