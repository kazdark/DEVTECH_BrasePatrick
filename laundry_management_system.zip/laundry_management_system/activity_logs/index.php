<?php

require_once "../includes/auth.php";
require_once "../config/database.php";

$result = $conn->query("
    SELECT
        a.id,
        u.fullname,
        a.action,
        a.created_at
    FROM activity_logs a
    INNER JOIN users u
        ON a.user_id = u.id
    ORDER BY a.id DESC
");

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Activity Logs</title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background: #f1f5f9;
            margin: 0;
        }

        .container {
            width: 90%;
            max-width: 1100px;
            margin: 40px auto;
        }

        .back {
            display: inline-block;
            margin-bottom: 20px;
            color: #2563eb;
            text-decoration: none;
        }

        .header {
            background: white;
            padding: 20px 25px;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.08);
            margin-bottom: 20px;
        }

        .header h1 {
            margin: 0;
        }

        .table-box {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.08);
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }

        th {
            background: #2563eb;
            color: white;
        }

        .empty {
            text-align: center;
            padding: 20px;
        }

    </style>

</head>

<body>

<div class="container">

    <a
        class="back"
        href="../dashboard.php"
    >
        ← Back to Dashboard
    </a>


    <div class="header">

        <h1>
            Activity Logs
        </h1>

    </div>


    <div class="table-box">

        <table>

            <thead>

                <tr>

                    <th>ID</th>
                    <th>User</th>
                    <th>Action</th>
                    <th>Date and Time</th>

                </tr>

            </thead>

            <tbody>

                <?php if ($result && $result->num_rows > 0): ?>

                    <?php while ($log = $result->fetch_assoc()): ?>

                        <tr>

                            <td>
                                <?php echo $log["id"]; ?>
                            </td>

                            <td>
                                <?php
                                echo htmlspecialchars(
                                    $log["fullname"]
                                );
                                ?>
                            </td>

                            <td>
                                <?php
                                echo htmlspecialchars(
                                    $log["action"]
                                );
                                ?>
                            </td>

                            <td>
                                <?php
                                echo htmlspecialchars(
                                    $log["created_at"]
                                );
                                ?>
                            </td>

                        </tr>

                    <?php endwhile; ?>

                <?php else: ?>

                    <tr>

                        <td
                            colspan="4"
                            class="empty"
                        >
                            No activity logs recorded yet.
                        </td>

                    </tr>

                <?php endif; ?>

            </tbody>

        </table>

    </div>

</div>

</body>

</html>