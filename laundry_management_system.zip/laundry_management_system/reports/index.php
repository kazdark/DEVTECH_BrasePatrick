<?php

require_once "../includes/auth.php";
require_once "../config/database.php";

/*
|--------------------------------------------------------------------------
| Daily Sales
|--------------------------------------------------------------------------
*/

$daily_result = $conn->query("
    SELECT
        DATE(payment_date) AS sale_date,
        SUM(amount) AS total_sales
    FROM payments
    WHERE DATE(payment_date) = CURDATE()
    GROUP BY DATE(payment_date)
");

$daily_sales = 0;

if ($daily_result && $daily_result->num_rows > 0) {
    $row = $daily_result->fetch_assoc();
    $daily_sales = $row["total_sales"];
}


/*
|--------------------------------------------------------------------------
| Weekly Sales
|--------------------------------------------------------------------------
*/

$weekly_result = $conn->query("
    SELECT
        SUM(amount) AS total_sales
    FROM payments
    WHERE YEARWEEK(payment_date, 1)
        = YEARWEEK(CURDATE(), 1)
");

$weekly_sales = 0;

if ($weekly_result) {
    $row = $weekly_result->fetch_assoc();
    $weekly_sales = $row["total_sales"] ?? 0;
}


/*
|--------------------------------------------------------------------------
| Monthly Sales
|--------------------------------------------------------------------------
*/

$monthly_result = $conn->query("
    SELECT
        SUM(amount) AS total_sales
    FROM payments
    WHERE YEAR(payment_date) = YEAR(CURDATE())
    AND MONTH(payment_date) = MONTH(CURDATE())
");

$monthly_sales = 0;

if ($monthly_result) {
    $row = $monthly_result->fetch_assoc();
    $monthly_sales = $row["total_sales"] ?? 0;
}


/*
|--------------------------------------------------------------------------
| Recent Payments
|--------------------------------------------------------------------------
*/

$recent_result = $conn->query("
    SELECT
        p.payment_date,
        o.order_number,
        c.fullname AS customer_name,
        p.amount
    FROM payments p
    INNER JOIN laundry_orders o
        ON p.order_id = o.id
    INNER JOIN customers c
        ON o.customer_id = c.id
    ORDER BY p.payment_date DESC
    LIMIT 10
");

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Sales Reports</title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background: #f1f5f9;
            margin: 0;
        }

        .container {
            width: 90%;
            max-width: 1200px;
            margin: 40px auto;
        }

        .back {
            display: inline-block;
            margin-bottom: 20px;
            color: #2563eb;
            text-decoration: none;
        }

        .header {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.08);
            margin-bottom: 20px;
        }

        .header h1 {
            margin: 0;
        }

        .cards {
            display: grid;
            grid-template-columns:
                repeat(auto-fit, minmax(220px, 1fr));

            gap: 20px;
            margin-bottom: 25px;
        }

        .card {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.08);
        }

        .card h3 {
            margin-top: 0;
            color: #555;
        }

        .amount {
            font-size: 28px;
            font-weight: bold;
            color: #2563eb;
        }

        .table-box {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.08);
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }

        th {
            background: #2563eb;
            color: white;
        }

        .empty {
            text-align: center;
        }

    </style>

</head>

<body>

<div class="container">

    <a
        class="back"
        href="../dashboard.php"
    >
        ← Back to Dashboard
    </a>


    <div class="header">

        <h1>
            Sales Reports
        </h1>

    </div>


    <!-- Sales Summary -->

    <div class="cards">

        <div class="card">

            <h3>
                Daily Sales
            </h3>

            <div class="amount">

                ₱<?php echo number_format($daily_sales, 2); ?>

            </div>

        </div>


        <div class="card">

            <h3>
                Weekly Sales
            </h3>

            <div class="amount">

                ₱<?php echo number_format($weekly_sales, 2); ?>

            </div>

        </div>


        <div class="card">

            <h3>
                Monthly Sales
            </h3>

            <div class="amount">

                ₱<?php echo number_format($monthly_sales, 2); ?>

            </div>

        </div>

    </div>


    <!-- Recent Payments -->

    <div class="table-box">

        <h2>
            Recent Payments
        </h2>

        <table>

            <thead>

                <tr>

                    <th>Date</th>
                    <th>Order Number</th>
                    <th>Customer</th>
                    <th>Amount</th>

                </tr>

            </thead>

            <tbody>

                <?php if ($recent_result && $recent_result->num_rows > 0): ?>

                    <?php while ($payment = $recent_result->fetch_assoc()): ?>

                        <tr>

                            <td>
                                <?php
                                echo htmlspecialchars(
                                    $payment["payment_date"]
                                );
                                ?>
                            </td>

                            <td>
                                <?php
                                echo htmlspecialchars(
                                    $payment["order_number"]
                                );
                                ?>
                            </td>

                            <td>
                                <?php
                                echo htmlspecialchars(
                                    $payment["customer_name"]
                                );
                                ?>
                            </td>

                            <td>
                                ₱<?php
                                echo number_format(
                                    $payment["amount"],
                                    2
                                );
                                ?>
                            </td>

                        </tr>

                    <?php endwhile; ?>

                <?php else: ?>

                    <tr>

                        <td
                            colspan="4"
                            class="empty"
                        >
                            No payments recorded yet.
                        </td>

                    </tr>

                <?php endif; ?>

            </tbody>

        </table>

    </div>

</div>

</body>

</html>