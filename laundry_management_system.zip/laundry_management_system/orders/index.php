<?php

require_once "../includes/auth.php";
require_once "../config/database.php";

$result = $conn->query("
    SELECT
        o.id,
        o.order_number,
        c.fullname AS customer_name,
        s.service_name,
        b.bag_name,
        o.quantity,
        o.total_amount,
        o.amount_paid,
        o.payment_status,
        o.order_status,
        o.received_at
    FROM laundry_orders o
    INNER JOIN customers c ON o.customer_id = c.id
    INNER JOIN services s ON o.service_id = s.id
    INNER JOIN bag_sizes b ON o.bag_size_id = b.id
    ORDER BY o.id DESC
");

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Order Management</title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background: #f1f5f9;
            margin: 0;
        }

        .container {
            width: 95%;
            margin: 30px auto;
        }

        .top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .top a {
            background: #2563eb;
            color: white;
            padding: 10px 15px;
            text-decoration: none;
            border-radius: 6px;
        }

        .back {
            display: inline-block;
            margin-bottom: 15px;
            color: #2563eb;
            text-decoration: none;
        }

        .table-box {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.08);
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
            text-align: left;
            white-space: nowrap;
        }

        th {
            background: #2563eb;
            color: white;
        }

        .empty {
            text-align: center;
        }

        .edit-btn {
            background: #2563eb;
            color: white;
            padding: 7px 12px;
            text-decoration: none;
            border-radius: 5px;
            display: inline-block;
        }

        .edit-btn:hover {
            background: #1d4ed8;
        }

    </style>

</head>

<body>

<div class="container">

    <a class="back" href="../dashboard.php">
        ← Back to Dashboard
    </a>

    <div class="top">

        <h1>Order Management</h1>

        <a href="add.php">
            + New Order
        </a>

    </div>

    <div class="table-box">

        <table>

            <thead>

                <tr>

                    <th>ID</th>
                    <th>Order Number</th>
                    <th>Customer</th>
                    <th>Service</th>
                    <th>Bag Size</th>
                    <th>Weight (kg)</th>
                    <th>Total Amount</th>
                    <th>Amount Paid</th>
                    <th>Payment Status</th>
                    <th>Order Status</th>
                    <th>Received At</th>
                    <th>Action</th>

                </tr>

            </thead>

            <tbody>

                <?php if ($result && $result->num_rows > 0): ?>

                    <?php while ($order = $result->fetch_assoc()): ?>

                        <tr>

                            <td>
                                <?php echo $order['id']; ?>
                            </td>

                            <td>
                                <?php echo htmlspecialchars($order['order_number']); ?>
                            </td>

                            <td>
                                <?php echo htmlspecialchars($order['customer_name']); ?>
                            </td>

                            <td>
                                <?php echo htmlspecialchars($order['service_name']); ?>
                            </td>

                            <td>
                                <?php echo htmlspecialchars($order['bag_name']); ?>
                            </td>

                            <td>
                                <?php echo number_format($order['quantity'], 2); ?>
                            </td>

                            <td>
                                ₱<?php echo number_format($order['total_amount'], 2); ?>
                            </td>

                            <td>
                                ₱<?php echo number_format($order['amount_paid'], 2); ?>
                            </td>

                            <td>
                                <?php echo htmlspecialchars($order['payment_status']); ?>
                            </td>

                            <td>
                                <?php echo htmlspecialchars($order['order_status']); ?>
                            </td>

                            <td>
                                <?php echo htmlspecialchars($order['received_at']); ?>
                            </td>

                            <td>

                                <a
                                    class="edit-btn"
                                    href="edit.php?id=<?php echo $order['id']; ?>"
                                >
                                    Edit
                                </a>

                            </td>

                        </tr>

                    <?php endwhile; ?>

                <?php else: ?>

                    <tr>

                        <td colspan="12" class="empty">
                            No orders registered yet.
                        </td>

                    </tr>

                <?php endif; ?>

            </tbody>

        </table>

    </div>

</div>

</body>

</html>