<?php

require_once "../includes/auth.php";
require_once "../config/database.php";
require_once "../includes/activity_log.php";

$error = "";

/*
|--------------------------------------------------------------------------
| Get Customers
|--------------------------------------------------------------------------
*/

$customers = $conn->query("
    SELECT id, fullname
    FROM customers
    ORDER BY fullname ASC
");

/*
|--------------------------------------------------------------------------
| Get Services with Pricing
|--------------------------------------------------------------------------
*/

$services = $conn->query("
    SELECT
        s.id,
        s.service_name,
        p.price_per_kg
    FROM services s
    INNER JOIN pricing p
        ON s.id = p.service_id
    WHERE s.status = 'active'
    ORDER BY s.service_name ASC
");

/*
|--------------------------------------------------------------------------
| Get Bag Sizes
|--------------------------------------------------------------------------
*/

$bag_sizes = $conn->query("
    SELECT id, bag_name
    FROM bag_sizes
    WHERE status = 'Active'
    ORDER BY bag_name ASC
");

/*
|--------------------------------------------------------------------------
| Save Order
|--------------------------------------------------------------------------
*/

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $customer_id = isset($_POST["customer_id"])
        ? (int) $_POST["customer_id"]
        : 0;

    $service_id = isset($_POST["service_id"])
        ? (int) $_POST["service_id"]
        : 0;

    $bag_size_id = isset($_POST["bag_size_id"])
        ? (int) $_POST["bag_size_id"]
        : 0;

    $quantity = isset($_POST["quantity"])
        ? (float) $_POST["quantity"]
        : 0;

    $amount_paid = isset($_POST["amount_paid"])
        ? (float) $_POST["amount_paid"]
        : 0;

    /*
    |--------------------------------------------------------------------------
    | Validate Input
    |--------------------------------------------------------------------------
    */

    if ($customer_id <= 0) {

        $error = "Please select a customer.";

    } elseif ($service_id <= 0) {

        $error = "Please select a laundry service.";

    } elseif ($bag_size_id <= 0) {

        $error = "Please select a bag size.";

    } elseif ($quantity <= 0) {

        $error = "Please enter the laundry weight.";

    } elseif ($amount_paid < 0) {

        $error = "Amount paid cannot be negative.";

    } else {

        /*
        |--------------------------------------------------------------------------
        | Get Price per KG
        |--------------------------------------------------------------------------
        */

        $stmt = $conn->prepare("
            SELECT price_per_kg
            FROM pricing
            WHERE service_id = ?
            LIMIT 1
        ");

        $stmt->bind_param("i", $service_id);
        $stmt->execute();

        $price_result = $stmt->get_result();
        $pricing = $price_result->fetch_assoc();

        $stmt->close();

        if (!$pricing) {

            $error = "No pricing found for the selected service.";

        } else {

            $price_per_kg = (float) $pricing["price_per_kg"];

            /*
            |--------------------------------------------------------------------------
            | Calculate Total
            |--------------------------------------------------------------------------
            */

            $total_amount = $quantity * $price_per_kg;

            /*
            |--------------------------------------------------------------------------
            | Check Payment
            |--------------------------------------------------------------------------
            */

            if ($amount_paid > $total_amount) {

                $error = "Amount paid cannot be greater than the total amount of ₱"
                    . number_format($total_amount, 2);

            } else {

                /*
                |--------------------------------------------------------------------------
                | Determine Payment Status
                |--------------------------------------------------------------------------
                */

                if ($amount_paid <= 0) {

                    $payment_status = "unpaid";

                } elseif ($amount_paid < $total_amount) {

                    $payment_status = "partial";

                } else {

                    $payment_status = "paid";
                }

                /*
                |--------------------------------------------------------------------------
                | Generate Order Number
                |--------------------------------------------------------------------------
                */

                $order_number =
                    "ORD-" .
                    date("YmdHis") .
                    "-" .
                    rand(100, 999);

                $order_status = "received";

                $created_by = $_SESSION["user_id"];

                /*
                |--------------------------------------------------------------------------
                | Start Transaction
                |--------------------------------------------------------------------------
                */

                $conn->begin_transaction();

                try {

                    /*
                    |--------------------------------------------------------------------------
                    | Insert Order
                    |--------------------------------------------------------------------------
                    */

                    $stmt = $conn->prepare("
                        INSERT INTO laundry_orders
                        (
                            order_number,
                            customer_id,
                            service_id,
                            bag_size_id,
                            quantity,
                            total_amount,
                            amount_paid,
                            payment_status,
                            order_status,
                            created_by
                        )
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ");

                    $stmt->bind_param(
                        "siiidddssi",
                        $order_number,
                        $customer_id,
                        $service_id,
                        $bag_size_id,
                        $quantity,
                        $total_amount,
                        $amount_paid,
                        $payment_status,
                        $order_status,
                        $created_by
                    );

                    if (!$stmt->execute()) {
                        throw new Exception("Failed to create order.");
                    }

                    $order_id = $conn->insert_id;

                    $stmt->close();

                    /*
                    |--------------------------------------------------------------------------
                    | Automatically Record Initial Payment
                    |--------------------------------------------------------------------------
                    */

                    if ($amount_paid > 0) {

                        $stmt = $conn->prepare("
                            INSERT INTO payments
                            (
                                order_id,
                                amount,
                                recorded_by
                            )
                            VALUES (?, ?, ?)
                        ");

                        $stmt->bind_param(
                            "idi",
                            $order_id,
                            $amount_paid,
                            $created_by
                        );

                        if (!$stmt->execute()) {
                            throw new Exception("Failed to record payment.");
                        }

                        $stmt->close();
                    }

                    /*
                    |--------------------------------------------------------------------------
                    | Commit Transaction
                    |--------------------------------------------------------------------------
                    */

                    $conn->commit();

                    /*
                    |--------------------------------------------------------------------------
                    | Record Activity Log
                    |--------------------------------------------------------------------------
                    */

                    logActivity(
                        $conn,
                        "Created new order: " . $order_number
                    );

                    header("Location: index.php");
                    exit();

                } catch (Exception $e) {

                    $conn->rollback();

                    $error = $e->getMessage();
                }
            }
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Add New Order</title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background: #f1f5f9;
            margin: 0;
        }

        .container {
            width: 500px;
            max-width: 90%;
            margin: 40px auto;
        }

        .back {
            display: inline-block;
            margin-bottom: 15px;
            color: #2563eb;
            text-decoration: none;
        }

        .form-box {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.08);
        }

        h1 {
            margin-top: 0;
            margin-bottom: 25px;
        }

        label {
            display: block;
            margin-bottom: 7px;
            font-weight: bold;
        }

        select,
        input {
            width: 100%;
            padding: 10px;
            margin-bottom: 18px;
            border: 1px solid #ccc;
            border-radius: 6px;
            box-sizing: border-box;
            font-size: 14px;
        }

        button {
            width: 100%;
            background: #2563eb;
            color: white;
            border: none;
            padding: 12px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 15px;
        }

        button:hover {
            background: #1d4ed8;
        }

        .error {
            background: #fee2e2;
            color: #b91c1c;
            padding: 10px;
            border-radius: 6px;
            margin-bottom: 18px;
        }

        .price-box {
            background: #eff6ff;
            color: #1e40af;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 18px;
        }

    </style>

</head>

<body>

<div class="container">

    <a class="back" href="index.php">
        ← Back to Orders
    </a>

    <div class="form-box">

        <h1>New Order</h1>

        <?php if ($error !== ""): ?>

            <div class="error">
                <?php echo htmlspecialchars($error); ?>
            </div>

        <?php endif; ?>

        <form method="POST">

            <label for="customer_id">
                Customer
            </label>

            <select name="customer_id" id="customer_id" required>

                <option value="">
                    -- Select Customer --
                </option>

                <?php if ($customers && $customers->num_rows > 0): ?>

                    <?php while ($customer = $customers->fetch_assoc()): ?>

                        <option value="<?php echo $customer["id"]; ?>">

                            <?php echo htmlspecialchars($customer["fullname"]); ?>

                        </option>

                    <?php endwhile; ?>

                <?php endif; ?>

            </select>

            <label for="service_id">
                Laundry Service
            </label>

            <select name="service_id" id="service_id" required>

                <option value="">
                    -- Select Service --
                </option>

                <?php if ($services && $services->num_rows > 0): ?>

                    <?php while ($service = $services->fetch_assoc()): ?>

                        <option
                            value="<?php echo $service["id"]; ?>"
                            data-price="<?php echo $service["price_per_kg"]; ?>"
                        >

                            <?php echo htmlspecialchars($service["service_name"]); ?>

                            - ₱<?php echo number_format($service["price_per_kg"], 2); ?>/kg

                        </option>

                    <?php endwhile; ?>

                <?php endif; ?>

            </select>

            <label for="bag_size_id">
                Bag Size
            </label>

            <select name="bag_size_id" id="bag_size_id" required>

                <option value="">
                    -- Select Bag Size --
                </option>

                <?php if ($bag_sizes && $bag_sizes->num_rows > 0): ?>

                    <?php while ($bag = $bag_sizes->fetch_assoc()): ?>

                        <option value="<?php echo $bag["id"]; ?>">

                            <?php echo htmlspecialchars($bag["bag_name"]); ?>

                        </option>

                    <?php endwhile; ?>

                <?php endif; ?>

            </select>

            <label for="quantity">
                Laundry Weight (kg)
            </label>

            <input
                type="number"
                name="quantity"
                id="quantity"
                step="0.01"
                min="0.01"
                placeholder="Enter weight in kg"
                required
            >

            <div class="price-box">

                Price per KG:
                <strong>
                    ₱<span id="pricePerKg">0.00</span>
                </strong>

                <br><br>

                Total Amount:
                <strong>
                    ₱<span id="totalAmount">0.00</span>
                </strong>

            </div>

            <label for="amount_paid">
                Amount Paid
            </label>

            <input
                type="number"
                name="amount_paid"
                id="amount_paid"
                step="0.01"
                min="0"
                value="0"
                placeholder="Enter amount paid"
                required
            >

            <button type="submit">
                Create Order
            </button>

        </form>

    </div>

</div>

<script>

    const serviceSelect = document.getElementById("service_id");
    const quantityInput = document.getElementById("quantity");

    const pricePerKgDisplay = document.getElementById("pricePerKg");
    const totalAmountDisplay = document.getElementById("totalAmount");

    function calculateTotal() {

        const selectedOption =
            serviceSelect.options[serviceSelect.selectedIndex];

        const price =
            parseFloat(selectedOption.dataset.price) || 0;

        const quantity =
            parseFloat(quantityInput.value) || 0;

        const total =
            price * quantity;

        pricePerKgDisplay.textContent =
            price.toFixed(2);

        totalAmountDisplay.textContent =
            total.toFixed(2);
    }

    serviceSelect.addEventListener(
        "change",
        calculateTotal
    );

    quantityInput.addEventListener(
        "input",
        calculateTotal
    );

</script>

</body>

</html>