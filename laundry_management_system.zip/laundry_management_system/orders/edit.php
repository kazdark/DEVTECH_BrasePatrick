<?php

require_once "../includes/auth.php";
require_once "../config/database.php";
require_once "../includes/activity_log.php";

if (!isset($_GET["id"]) || !is_numeric($_GET["id"])) {
    header("Location: index.php");
    exit();
}

$id = (int) $_GET["id"];

$stmt = $conn->prepare("
    SELECT
        o.id,
        o.order_number,
        o.order_status,
        o.payment_status,
        o.amount_paid,
        o.total_amount,
        c.fullname AS customer_name
    FROM laundry_orders o
    INNER JOIN customers c ON o.customer_id = c.id
    WHERE o.id = ?
    LIMIT 1
");

$stmt->bind_param("i", $id);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header("Location: index.php");
    exit();
}

$order = $result->fetch_assoc();

$stmt->close();

$message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $order_status = $_POST["order_status"];
    $new_amount_paid = (float) $_POST["amount_paid"];

    $current_amount_paid = (float) $order["amount_paid"];
    $total_amount = (float) $order["total_amount"];

    if ($new_amount_paid < 0) {

        $message = "Amount paid cannot be negative.";

    } elseif ($new_amount_paid > $total_amount) {

        $message = "Amount paid cannot be greater than the total amount.";

    } else {

        if ($new_amount_paid == 0) {

            $payment_status = "unpaid";

        } elseif ($new_amount_paid < $total_amount) {

            $payment_status = "partial";

        } else {

            $payment_status = "paid";
            $new_amount_paid = $total_amount;

        }
    }

    if ($message === "") {

        $additional_payment =
            $new_amount_paid - $current_amount_paid;

        $conn->begin_transaction();

        try {

            /*
            |--------------------------------------------------------------------------
            | Update Order
            |--------------------------------------------------------------------------
            */

            $stmt = $conn->prepare("
                UPDATE laundry_orders
                SET
                    order_status = ?,
                    amount_paid = ?,
                    payment_status = ?
                WHERE id = ?
            ");

            $stmt->bind_param(
                "sdsi",
                $order_status,
                $new_amount_paid,
                $payment_status,
                $id
            );

            if (!$stmt->execute()) {
                throw new Exception("Failed to update order.");
            }

            $stmt->close();


            /*
            |--------------------------------------------------------------------------
            | Record Additional Payment
            |--------------------------------------------------------------------------
            */

            if ($additional_payment > 0) {

                $recorded_by = $_SESSION["user_id"];

                $payment_stmt = $conn->prepare("
                    INSERT INTO payments
                    (
                        order_id,
                        amount,
                        recorded_by
                    )
                    VALUES (?, ?, ?)
                ");

                $payment_stmt->bind_param(
                    "idi",
                    $id,
                    $additional_payment,
                    $recorded_by
                );

                if (!$payment_stmt->execute()) {
                    throw new Exception("Failed to record payment.");
                }

                $payment_stmt->close();
            }


            /*
            |--------------------------------------------------------------------------
            | Activity Log - Order Status
            |--------------------------------------------------------------------------
            */

            if ($order_status !== $order["order_status"]) {

                logActivity(
                    $conn,
                    "Updated order " . $order["order_number"] .
                    " status from " .
                    ucfirst($order["order_status"]) .
                    " to " .
                    ucfirst($order_status)
                );
            }


            /*
            |--------------------------------------------------------------------------
            | Commit Transaction
            |--------------------------------------------------------------------------
            */

            $conn->commit();

            header("Location: index.php");
            exit();

        } catch (Exception $e) {

            $conn->rollback();

            $message = $e->getMessage();
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Update Order</title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background: #f1f5f9;
            margin: 0;
        }

        .container {
            width: 90%;
            max-width: 600px;
            margin: 40px auto;
        }

        .back {
            display: inline-block;
            margin-bottom: 20px;
            color: #2563eb;
            text-decoration: none;
        }

        .box {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.08);
        }

        h1 {
            margin-top: 0;
        }

        .info {
            background: #f8fafc;
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 20px;
        }

        .info p {
            margin: 8px 0;
        }

        .group {
            margin-bottom: 18px;
        }

        label {
            display: block;
            margin-bottom: 7px;
            font-weight: bold;
        }

        input,
        select {
            width: 100%;
            padding: 10px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 15px;
        }

        button {
            width: 100%;
            padding: 12px;
            border: none;
            border-radius: 6px;
            background: #2563eb;
            color: white;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background: #1d4ed8;
        }

        .message {
            background: #fee2e2;
            color: #991b1b;
            padding: 10px;
            border-radius: 6px;
            margin-bottom: 15px;
        }

    </style>

</head>

<body>

<div class="container">

    <a class="back" href="index.php">
        ← Back to Orders
    </a>

    <div class="box">

        <h1>Update Order</h1>

        <?php if ($message !== ""): ?>

            <div class="message">
                <?php echo htmlspecialchars($message); ?>
            </div>

        <?php endif; ?>


        <div class="info">

            <p>
                <strong>Order Number:</strong>
                <?php echo htmlspecialchars($order["order_number"]); ?>
            </p>

            <p>
                <strong>Customer:</strong>
                <?php echo htmlspecialchars($order["customer_name"]); ?>
            </p>

            <p>
                <strong>Total Amount:</strong>
                ₱<?php echo number_format($order["total_amount"], 2); ?>
            </p>

            <p>
                <strong>Current Amount Paid:</strong>
                ₱<?php echo number_format($order["amount_paid"], 2); ?>
            </p>

        </div>


        <form method="POST">

            <div class="group">

                <label>
                    Order Status
                </label>

                <select name="order_status" required>

                    <option
                        value="received"
                        <?php
                        echo ($order["order_status"] === "received")
                            ? "selected"
                            : "";
                        ?>
                    >
                        Received
                    </option>

                    <option
                        value="washing"
                        <?php
                        echo ($order["order_status"] === "washing")
                            ? "selected"
                            : "";
                        ?>
                    >
                        Washing
                    </option>

                    <option
                        value="drying"
                        <?php
                        echo ($order["order_status"] === "drying")
                            ? "selected"
                            : "";
                        ?>
                    >
                        Drying
                    </option>

                    <option
                        value="folding"
                        <?php
                        echo ($order["order_status"] === "folding")
                            ? "selected"
                            : "";
                        ?>
                    >
                        Folding
                    </option>

                    <option
                        value="ready"
                        <?php
                        echo ($order["order_status"] === "ready")
                            ? "selected"
                            : "";
                        ?>
                    >
                        Ready
                    </option>

                    <option
                        value="claimed"
                        <?php
                        echo ($order["order_status"] === "claimed")
                            ? "selected"
                            : "";
                        ?>
                    >
                        Claimed
                    </option>

                </select>

            </div>


            <div class="group">

                <label>
                    Amount Paid
                </label>

                <input
                    type="number"
                    name="amount_paid"
                    min="0"
                    max="<?php echo htmlspecialchars($order["total_amount"]); ?>"
                    step="0.01"
                    value="<?php echo htmlspecialchars($order["amount_paid"]); ?>"
                    required
                >

            </div>


            <button type="submit">
                Update Order
            </button>

        </form>

    </div>

</div>

</body>

</html>