<?php

require_once "../includes/auth.php";
require_once "../config/database.php";
require_once "../includes/activity_log.php";

if (!isset($_GET["id"]) || !is_numeric($_GET["id"])) {
    header("Location: index.php");
    exit();
}

$id = (int) $_GET["id"];

/*
|--------------------------------------------------------------------------
| Get Service Name
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare("
    SELECT service_name
    FROM services
    WHERE id = ?
    LIMIT 1
");

$stmt->bind_param("i", $id);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header("Location: index.php");
    exit();
}

$service = $result->fetch_assoc();

$stmt->close();

$service_name = $service["service_name"];


/*
|--------------------------------------------------------------------------
| Delete Service
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare("
    DELETE FROM services
    WHERE id = ?
");

$stmt->bind_param("i", $id);

if ($stmt->execute()) {

    /*
    |--------------------------------------------------------------------------
    | Activity Log
    |--------------------------------------------------------------------------
    */

    logActivity(
        $conn,
        "Deleted service: " . $service_name
    );

    header("Location: index.php");
    exit();

} else {

    echo "Failed to delete service.";

}

$stmt->close();

?>