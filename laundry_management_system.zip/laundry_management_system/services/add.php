<?php

require_once "../includes/auth.php";
require_once "../config/database.php";
require_once "../includes/activity_log.php";

$message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $service_name = trim($_POST["service_name"]);
    $description_en = trim($_POST["description_en"]);
    $description_tl = trim($_POST["description_tl"]);

    if (
        $service_name === "" ||
        $description_en === "" ||
        $description_tl === ""
    ) {

        $message = "Please complete all fields.";

    } else {

        $stmt = $conn->prepare("
            INSERT INTO services
            (service_name, description_en, description_tl)
            VALUES (?, ?, ?)
        ");

        $stmt->bind_param(
            "sss",
            $service_name,
            $description_en,
            $description_tl
        );

        if ($stmt->execute()) {

            /*
            |--------------------------------------------------------------------------
            | Activity Log
            |--------------------------------------------------------------------------
            */

            logActivity(
                $conn,
                "Added new service: " . $service_name
            );

            header("Location: index.php");
            exit();

        } else {

            $message = "Failed to add service.";

        }

        $stmt->close();
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Add Laundry Service</title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background: #f1f5f9;
            margin: 0;
        }

        .container {
            width: 90%;
            max-width: 600px;
            margin: 40px auto;
        }

        .back {
            display: inline-block;
            margin-bottom: 20px;
            color: #2563eb;
            text-decoration: none;
        }

        .box {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.08);
        }

        h1 {
            margin-top: 0;
        }

        .group {
            margin-bottom: 18px;
        }

        label {
            display: block;
            margin-bottom: 7px;
            font-weight: bold;
        }

        input,
        textarea {
            width: 100%;
            padding: 10px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 15px;
        }

        textarea {
            min-height: 100px;
            resize: vertical;
        }

        button {
            width: 100%;
            padding: 12px;
            border: none;
            border-radius: 6px;
            background: #2563eb;
            color: white;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background: #1d4ed8;
        }

        .message {
            background: #fee2e2;
            color: #991b1b;
            padding: 10px;
            border-radius: 6px;
            margin-bottom: 15px;
        }

    </style>

</head>

<body>

<div class="container">

    <a class="back" href="index.php">
        ← Back to Services
    </a>

    <div class="box">

        <h1>Add Laundry Service</h1>

        <?php if ($message !== ""): ?>

            <div class="message">
                <?php echo htmlspecialchars($message); ?>
            </div>

        <?php endif; ?>

        <form method="POST">

            <div class="group">

                <label>
                    Service Name
                </label>

                <input
                    type="text"
                    name="service_name"
                    placeholder="Example: Wash"
                    required
                >

            </div>

            <div class="group">

                <label>
                    English Description
                </label>

                <textarea
                    name="description_en"
                    placeholder="Enter the English description of the service."
                    required
                ></textarea>

            </div>

            <div class="group">

                <label>
                    Tagalog Description
                </label>

                <textarea
                    name="description_tl"
                    placeholder="Ilagay ang Tagalog description ng service."
                    required
                ></textarea>

            </div>

            <button type="submit">
                Add Service
            </button>

        </form>

    </div>

</div>

</body>

</html>