<?php

require_once "includes/auth.php";
require_once "config/database.php";

/*
|--------------------------------------------------------------------------
| Dashboard Statistics
|--------------------------------------------------------------------------
*/

// Total Customers
$customer_result = $conn->query("
    SELECT COUNT(*) AS total
    FROM customers
");

$total_customers = 0;

if ($customer_result) {
    $row = $customer_result->fetch_assoc();
    $total_customers = $row["total"];
}


// Active Orders
$active_order_result = $conn->query("
    SELECT COUNT(*) AS total
    FROM laundry_orders
    WHERE order_status NOT IN ('claimed')
");

$active_orders = 0;

if ($active_order_result) {
    $row = $active_order_result->fetch_assoc();
    $active_orders = $row["total"];
}


// Ready for Pickup
$ready_result = $conn->query("
    SELECT COUNT(*) AS total
    FROM laundry_orders
    WHERE order_status = 'ready'
");

$ready_orders = 0;

if ($ready_result) {
    $row = $ready_result->fetch_assoc();
    $ready_orders = $row["total"];
}


// Today's Sales
$sales_result = $conn->query("
    SELECT COALESCE(SUM(amount), 0) AS total
    FROM payments
    WHERE DATE(payment_date) = CURDATE()
");

$today_sales = 0;

if ($sales_result) {
    $row = $sales_result->fetch_assoc();
    $today_sales = $row["total"];
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Dashboard</title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background: #f1f5f9;
            margin: 0;
        }

        .container {
            width: 90%;
            max-width: 1200px;
            margin: 40px auto;
        }

        .header {
            background: white;
            padding: 20px 25px;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.08);

            display: flex;
            justify-content: space-between;
            align-items: center;

            margin-bottom: 25px;
        }

        .header h1 {
            margin: 0;
        }

        .welcome {
            color: #555;
            margin-top: 5px;
        }

        .logout {
            background: #dc2626;
            color: white;
            padding: 9px 14px;
            text-decoration: none;
            border-radius: 6px;
        }

        .logout:hover {
            background: #b91c1c;
        }

        .cards {
            display: grid;
            grid-template-columns:
                repeat(auto-fit, minmax(200px, 1fr));

            gap: 20px;
            margin-bottom: 30px;
        }

        .card {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.08);
        }

        .card h3 {
            margin-top: 0;
            color: #555;
            font-size: 16px;
        }

        .number {
            font-size: 30px;
            font-weight: bold;
            color: #2563eb;
        }

        .menu {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.08);
        }

        .menu h2 {
            margin-top: 0;
            margin-bottom: 20px;
        }

        .buttons {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
        }

        .buttons a {
            background: #2563eb;
            color: white;
            padding: 12px 18px;
            text-decoration: none;
            border-radius: 6px;
        }

        .buttons a:hover {
            background: #1d4ed8;
        }

    </style>

</head>

<body>

<div class="container">

    <!-- Header -->

    <div class="header">

        <div>

            <h1>
                Laundry Management System
            </h1>

            <div class="welcome">

                Welcome,
                <strong>
                    <?php
                    echo htmlspecialchars(
                        $_SESSION["fullname"]
                    );
                    ?>
                </strong>

            </div>

        </div>

        <div>

            <a
                class="logout"
                href="logout.php"
            >
                Logout
            </a>

        </div>

    </div>


    <!-- Dashboard Cards -->

    <div class="cards">

        <div class="card">

            <h3>
                Total Customers
            </h3>

            <div class="number">
                <?php echo $total_customers; ?>
            </div>

        </div>


        <div class="card">

            <h3>
                Active Orders
            </h3>

            <div class="number">
                <?php echo $active_orders; ?>
            </div>

        </div>


        <div class="card">

            <h3>
                Ready for Pickup
            </h3>

            <div class="number">
                <?php echo $ready_orders; ?>
            </div>

        </div>


        <div class="card">

            <h3>
                Today's Sales
            </h3>

            <div class="number">

                ₱<?php
                echo number_format(
                    $today_sales,
                    2
                );
                ?>

            </div>

        </div>

    </div>


    <!-- System Management -->

    <div class="menu">

        <h2>
            System Management
        </h2>

        <div class="buttons">

            <a href="customers/index.php">
                Customer Management
            </a>

            <a href="services/index.php">
                Service Management
            </a>

            <a href="bag_sizes/index.php">
                Bag Size Management
            </a>

            <a href="orders/index.php">
                Order Management
            </a>

            <a href="payments/index.php">
                Payment Management
            </a>

            <a href="reports/index.php">
                Sales Reports
            </a>

            <a href="activity_logs/index.php">
                Activity Logs
            </a>

        </div>

    </div>

</div>

</body>

</html>