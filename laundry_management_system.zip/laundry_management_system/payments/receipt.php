<?php

require_once "../includes/auth.php";
require_once "../config/database.php";

if (!isset($_GET["id"]) || !is_numeric($_GET["id"])) {
    header("Location: index.php");
    exit();
}

$payment_id = (int) $_GET["id"];

$stmt = $conn->prepare("
    SELECT
        p.id AS payment_id,
        p.amount AS payment_amount,
        p.payment_date,

        o.id AS order_id,
        o.order_number,
        o.quantity,
        o.total_amount,
        o.amount_paid,
        o.payment_status,
        o.order_status,

        c.fullname AS customer_name,

        s.service_name,
        b.bag_name,

        u.fullname AS recorded_by

    FROM payments p

    INNER JOIN laundry_orders o
        ON p.order_id = o.id

    INNER JOIN customers c
        ON o.customer_id = c.id

    INNER JOIN services s
        ON o.service_id = s.id

    INNER JOIN bag_sizes b
        ON o.bag_size_id = b.id

    LEFT JOIN users u
        ON p.recorded_by = u.id

    WHERE p.id = ?

    LIMIT 1
");

$stmt->bind_param("i", $payment_id);
$stmt->execute();

$result = $stmt->get_result();
$receipt = $result->fetch_assoc();

$stmt->close();

if (!$receipt) {
    die("Payment record not found.");
}

$total_amount = (float) $receipt["total_amount"];
$amount_paid = (float) $receipt["amount_paid"];

$remaining_balance = $total_amount - $amount_paid;

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Payment Receipt</title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background: #f1f5f9;
            margin: 0;
            padding: 30px;
        }

        .receipt {
            width: 500px;
            max-width: 95%;
            margin: auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.08);
        }

        .header {
            text-align: center;
            border-bottom: 2px solid #2563eb;
            padding-bottom: 15px;
            margin-bottom: 20px;
        }

        .header h1 {
            margin: 0;
            color: #2563eb;
        }

        .header p {
            margin: 5px 0;
            color: #555;
        }

        .section {
            margin-bottom: 20px;
        }

        .row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
            gap: 20px;
        }

        .label {
            font-weight: bold;
        }

        .total {
            border-top: 2px solid #ddd;
            padding-top: 12px;
            font-size: 18px;
        }

        .paid {
            color: #15803d;
            font-weight: bold;
        }

        .balance {
            color: #dc2626;
            font-weight: bold;
        }

        .status {
            text-transform: capitalize;
            font-weight: bold;
        }

        .buttons {
            text-align: center;
            margin-top: 25px;
        }

        .buttons a,
        .buttons button {
            display: inline-block;
            padding: 10px 15px;
            margin: 5px;
            border: none;
            border-radius: 6px;
            text-decoration: none;
            cursor: pointer;
            font-size: 14px;
        }

        .back {
            background: #64748b;
            color: white;
        }

        .print {
            background: #2563eb;
            color: white;
        }

        @media print {

            body {
                background: white;
                padding: 0;
            }

            .receipt {
                width: 100%;
                max-width: none;
                box-shadow: none;
                padding: 10px;
            }

            .buttons {
                display: none;
            }

        }

    </style>

</head>

<body>

<div class="receipt">

    <div class="header">

        <h1>
            Laundry Management System
        </h1>

        <p>
            Payment Receipt
        </p>

    </div>


    <div class="section">

        <div class="row">

            <span class="label">
                Receipt No.:
            </span>

            <span>
                <?php echo $receipt["payment_id"]; ?>
            </span>

        </div>


        <div class="row">

            <span class="label">
                Order Number:
            </span>

            <span>
                <?php echo htmlspecialchars($receipt["order_number"]); ?>
            </span>

        </div>


        <div class="row">

            <span class="label">
                Payment Date:
            </span>

            <span>
                <?php echo htmlspecialchars($receipt["payment_date"]); ?>
            </span>

        </div>

    </div>


    <div class="section">

        <h3>
            Customer Information
        </h3>

        <div class="row">

            <span class="label">
                Customer:
            </span>

            <span>
                <?php echo htmlspecialchars($receipt["customer_name"]); ?>
            </span>

        </div>

    </div>


    <div class="section">

        <h3>
            Order Information
        </h3>


        <div class="row">

            <span class="label">
                Service:
            </span>

            <span>
                <?php echo htmlspecialchars($receipt["service_name"]); ?>
            </span>

        </div>


        <div class="row">

            <span class="label">
                Bag Size:
            </span>

            <span>
                <?php echo htmlspecialchars($receipt["bag_name"]); ?>
            </span>

        </div>


        <div class="row">

            <span class="label">
                Weight:
            </span>

            <span>
                <?php echo number_format($receipt["quantity"], 2); ?> kg
            </span>

        </div>


        <div class="row">

            <span class="label">
                Order Status:
            </span>

            <span class="status">
                <?php echo htmlspecialchars($receipt["order_status"]); ?>
            </span>

        </div>

    </div>


    <div class="section">

        <h3>
            Payment Summary
        </h3>


        <div class="row">

            <span class="label">
                Total Amount:
            </span>

            <span>
                ₱<?php echo number_format($total_amount, 2); ?>
            </span>

        </div>


        <div class="row">

            <span class="label">
                Amount Paid:
            </span>

            <span class="paid">
                ₱<?php echo number_format($amount_paid, 2); ?>
            </span>

        </div>


        <div class="row total">

            <span class="label">
                Remaining Balance:
            </span>

            <span class="balance">
                ₱<?php echo number_format($remaining_balance, 2); ?>
            </span>

        </div>


        <div class="row">

            <span class="label">
                Payment Status:
            </span>

            <span class="status">
                <?php echo htmlspecialchars($receipt["payment_status"]); ?>
            </span>

        </div>

    </div>


    <div class="section">

        <div class="row">

            <span class="label">
                Recorded By:
            </span>

            <span>
                <?php
                echo htmlspecialchars(
                    $receipt["recorded_by"] ?? "Unknown"
                );
                ?>
            </span>

        </div>

    </div>


    <div class="buttons">

        <a
            class="back"
            href="index.php"
        >
            ← Back
        </a>

        <button
            class="print"
            onclick="window.print()"
        >
            Print Receipt
        </button>

    </div>

</div>

</body>

</html>