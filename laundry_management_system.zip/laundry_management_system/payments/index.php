<?php

require_once "../includes/auth.php";
require_once "../config/database.php";

$result = $conn->query("
    SELECT
        p.id,
        p.order_id,
        o.order_number,
        c.fullname AS customer_name,
        p.amount,
        p.payment_date,
        u.fullname AS recorded_by
    FROM payments p
    INNER JOIN laundry_orders o
        ON p.order_id = o.id
    INNER JOIN customers c
        ON o.customer_id = c.id
    LEFT JOIN users u
        ON p.recorded_by = u.id
    ORDER BY p.id DESC
");

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Payment Management</title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background: #f1f5f9;
            margin: 0;
        }

        .container {
            width: 95%;
            margin: 30px auto;
        }

        .top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .top a {
            background: #2563eb;
            color: white;
            padding: 10px 15px;
            text-decoration: none;
            border-radius: 6px;
        }

        .top a:hover {
            background: #1d4ed8;
        }

        .back {
            display: inline-block;
            margin-bottom: 15px;
            color: #2563eb;
            text-decoration: none;
        }

        .table-box {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.08);
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
            text-align: left;
            white-space: nowrap;
        }

        th {
            background: #2563eb;
            color: white;
        }

        .empty {
            text-align: center;
        }

        .amount {
            font-weight: bold;
        }

        .receipt-btn {
            background: #16a34a;
            color: white;
            padding: 7px 12px;
            text-decoration: none;
            border-radius: 5px;
            display: inline-block;
        }

        .receipt-btn:hover {
            background: #15803d;
        }

    </style>

</head>

<body>

<div class="container">

    <a class="back" href="../dashboard.php">
        ← Back to Dashboard
    </a>

    <div class="top">

        <h1>Payment Management</h1>

        <a href="add.php">
            + Record Payment
        </a>

    </div>

    <div class="table-box">

        <table>

            <thead>

                <tr>

                    <th>ID</th>
                    <th>Order Number</th>
                    <th>Customer</th>
                    <th>Amount</th>
                    <th>Payment Date</th>
                    <th>Recorded By</th>
                    <th>Action</th>

                </tr>

            </thead>

            <tbody>

                <?php if ($result && $result->num_rows > 0): ?>

                    <?php while ($payment = $result->fetch_assoc()): ?>

                        <tr>

                            <td>
                                <?php echo $payment['id']; ?>
                            </td>

                            <td>
                                <?php echo htmlspecialchars($payment['order_number']); ?>
                            </td>

                            <td>
                                <?php echo htmlspecialchars($payment['customer_name']); ?>
                            </td>

                            <td class="amount">
                                ₱<?php echo number_format($payment['amount'], 2); ?>
                            </td>

                            <td>
                                <?php echo htmlspecialchars($payment['payment_date']); ?>
                            </td>

                            <td>
                                <?php
                                echo htmlspecialchars(
                                    $payment['recorded_by'] ?? 'Unknown'
                                );
                                ?>
                            </td>

                            <td>

                                <a
                                    class="receipt-btn"
                                    href="receipt.php?id=<?php echo $payment['id']; ?>"
                                >
                                    View Receipt
                                </a>

                            </td>

                        </tr>

                    <?php endwhile; ?>

                <?php else: ?>

                    <tr>

                        <td colspan="7" class="empty">
                            No payments recorded yet.
                        </td>

                    </tr>

                <?php endif; ?>

            </tbody>

        </table>

    </div>

</div>

</body>

</html>