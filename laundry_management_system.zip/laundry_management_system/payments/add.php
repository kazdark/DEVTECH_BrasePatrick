<?php

require_once "../includes/auth.php";
require_once "../config/database.php";
require_once "../includes/activity_log.php";

$error = "";

/*
|--------------------------------------------------------------------------
| Get Available Orders
|--------------------------------------------------------------------------
*/

$orders = $conn->query("
    SELECT
        o.id,
        o.order_number,
        c.fullname AS customer_name,
        o.total_amount,
        o.amount_paid
    FROM laundry_orders o
    INNER JOIN customers c
        ON o.customer_id = c.id
    ORDER BY o.id DESC
");

/*
|--------------------------------------------------------------------------
| Save Payment
|--------------------------------------------------------------------------
*/

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $order_id = isset($_POST["order_id"]) ? (int) $_POST["order_id"] : 0;
    $amount = isset($_POST["amount"]) ? (float) $_POST["amount"] : 0;

    if ($order_id <= 0) {

        $error = "Please select an order.";

    } elseif ($amount <= 0) {

        $error = "Payment amount must be greater than zero.";

    } else {

        /*
        |--------------------------------------------------------------------------
        | Get Order Information
        |--------------------------------------------------------------------------
        */

        $stmt = $conn->prepare("
            SELECT
                order_number,
                total_amount,
                amount_paid
            FROM laundry_orders
            WHERE id = ?
            LIMIT 1
        ");

        $stmt->bind_param("i", $order_id);
        $stmt->execute();

        $result = $stmt->get_result();
        $order = $result->fetch_assoc();

        $stmt->close();

        if (!$order) {

            $error = "Order not found.";

        } else {

            $order_number = $order["order_number"];
            $total_amount = (float) $order["total_amount"];
            $current_paid = (float) $order["amount_paid"];

            $remaining_balance = $total_amount - $current_paid;

            /*
            |--------------------------------------------------------------------------
            | Prevent Overpayment
            |--------------------------------------------------------------------------
            */

            if ($amount > $remaining_balance) {

                $error = "Payment cannot be greater than the remaining balance of ₱"
                    . number_format($remaining_balance, 2);

            } else {

                $new_amount_paid = $current_paid + $amount;

                /*
                |--------------------------------------------------------------------------
                | Determine Payment Status
                |--------------------------------------------------------------------------
                */

                if ($new_amount_paid <= 0) {

                    $payment_status = "unpaid";

                } elseif ($new_amount_paid < $total_amount) {

                    $payment_status = "partial";

                } else {

                    $payment_status = "paid";
                }

                /*
                |--------------------------------------------------------------------------
                | Insert Payment
                |--------------------------------------------------------------------------
                */

                $stmt = $conn->prepare("
                    INSERT INTO payments
                    (
                        order_id,
                        amount,
                        recorded_by
                    )
                    VALUES (?, ?, ?)
                ");

                $recorded_by = $_SESSION["user_id"];

                $stmt->bind_param(
                    "idi",
                    $order_id,
                    $amount,
                    $recorded_by
                );

                if ($stmt->execute()) {

                    $stmt->close();

                    /*
                    |--------------------------------------------------------------------------
                    | Update Order Payment Information
                    |--------------------------------------------------------------------------
                    */

                    $stmt = $conn->prepare("
                        UPDATE laundry_orders
                        SET
                            amount_paid = ?,
                            payment_status = ?
                        WHERE id = ?
                    ");

                    $stmt->bind_param(
                        "dsi",
                        $new_amount_paid,
                        $payment_status,
                        $order_id
                    );

                    if ($stmt->execute()) {

                        $stmt->close();

                        /*
                        |--------------------------------------------------------------------------
                        | Record Activity Log
                        |--------------------------------------------------------------------------
                        */

                        logActivity(
                            $conn,
                            "Recorded payment of ₱"
                            . number_format($amount, 2)
                            . " for order: "
                            . $order_number
                        );

                        header("Location: index.php");
                        exit();

                    } else {

                        $stmt->close();

                        $error = "Payment was recorded, but the order payment status could not be updated.";
                    }

                } else {

                    $error = "Failed to record payment.";

                    $stmt->close();
                }
            }
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Record Payment</title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background: #f1f5f9;
            margin: 0;
        }

        .container {
            width: 500px;
            max-width: 90%;
            margin: 50px auto;
        }

        .back {
            display: inline-block;
            margin-bottom: 15px;
            color: #2563eb;
            text-decoration: none;
        }

        .form-box {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.08);
        }

        h1 {
            margin-top: 0;
            margin-bottom: 25px;
        }

        label {
            display: block;
            margin-bottom: 7px;
            font-weight: bold;
        }

        select,
        input {
            width: 100%;
            padding: 10px;
            margin-bottom: 18px;
            border: 1px solid #ccc;
            border-radius: 6px;
            box-sizing: border-box;
            font-size: 14px;
        }

        button {
            width: 100%;
            background: #2563eb;
            color: white;
            border: none;
            padding: 12px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 15px;
        }

        button:hover {
            background: #1d4ed8;
        }

        .error {
            background: #fee2e2;
            color: #b91c1c;
            padding: 10px;
            border-radius: 6px;
            margin-bottom: 18px;
        }

        .balance {
            background: #eff6ff;
            color: #1e40af;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 18px;
        }

    </style>

</head>

<body>

<div class="container">

    <a class="back" href="index.php">
        ← Back to Payments
    </a>

    <div class="form-box">

        <h1>Record Payment</h1>

        <?php if ($error !== ""): ?>

            <div class="error">
                <?php echo htmlspecialchars($error); ?>
            </div>

        <?php endif; ?>

        <form method="POST">

            <label for="order_id">
                Order
            </label>

            <select name="order_id" id="order_id" required>

                <option value="">
                    -- Select Order --
                </option>

                <?php if ($orders && $orders->num_rows > 0): ?>

                    <?php while ($order = $orders->fetch_assoc()): ?>

                        <?php
                        $remaining = (float)$order["total_amount"]
                            - (float)$order["amount_paid"];
                        ?>

                        <?php if ($remaining > 0): ?>

                            <option
                                value="<?php echo $order["id"]; ?>"
                            >
                                <?php echo htmlspecialchars($order["order_number"]); ?>
                                -
                                <?php echo htmlspecialchars($order["customer_name"]); ?>
                                -
                                Balance: ₱<?php echo number_format($remaining, 2); ?>
                            </option>

                        <?php endif; ?>

                    <?php endwhile; ?>

                <?php endif; ?>

            </select>

            <label for="amount">
                Payment Amount
            </label>

            <input
                type="number"
                name="amount"
                id="amount"
                step="0.01"
                min="0.01"
                placeholder="Enter payment amount"
                required
            >

            <button type="submit">
                Record Payment
            </button>

        </form>

    </div>

</div>

</body>

</html>