var num1 = 90;
var num2 = 10;
if(num1>num2){
    console.log(num1+ "is greater");
}else{
    console.log(num2 + "is greater")
}

