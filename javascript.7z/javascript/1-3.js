var  number = 10;
if (number>0){
    console.log( "is positive.");
}else{
    console.log("is negative");
}