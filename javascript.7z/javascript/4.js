// 
let obj = {};

//
let person ={
    name: "Patricia",
    age: 96,
}

//
Object.setPrototypeOf(obj, person);

//
console.log(Object.getPrototypeOf(obj));

//Output: { name: 'Vincent' , age: 56  }

//check if the prototype of obj
//is equal to the person object
console.log(Object.getOwnPropertyDescriptor(ong)== person)
//Output: True