var number = 98;
if(number % 2 === 0)
  { console.log("It is even number");
  } else {  console.log("It is odd");
}