var number = 0;
if(number % 2 ===0)
{console.log("It is even number");

}else{
    console.log("it is odd number");
}