<?php
echo"Hello, World!";
?>