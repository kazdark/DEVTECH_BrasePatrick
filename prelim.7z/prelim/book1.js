class Book{
    constructor(title, author, publicationyear){
        this.title = title;
        this.author = author;
        this.publicationyear = publicationyear;
        
    }
    displayDetails(){
        console.log(`Title: ${this.title}`);
        console.log(`Author: ${this.author}`);
        console.log(`Publication Year: ${this.publicationyear}`);
    }
}
class Ebook extends Book{
    constructor(title, author, publicationyear, price){
        super(title, author, publicationyear);
        this.price = price;

    }
    displayDetails(){
        super.displayDetails();
        console.log(`Price: ${this.price}`);
    }
}
const ebook1 = new Ebook('The Attachment Style', 'Ria Martez', 2024, '$300.9')
ebook1.displayDetails();
const ebook2 = new Ebook('Harry Potter', 'JK Rowling', 1900, '$19.08')
ebook2.displayDetails();
const ebook3 = new Ebook('BOOK3', 'Author 2', 1988, '$25.33')
ebook3.displayDetails();
const ebook4 = new Ebook('Don Quixote', 'Miguel Cervantes', 1605, '$21.49')
ebook4.displayDetails();